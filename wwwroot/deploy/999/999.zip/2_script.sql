
gksu gedit /etc/environment


gksudo gedit /usr/share/X11/xorg.conf.d/20-intel.conf


sudo systemctl enable <service-name.service>

unarix@linuxlord ~ $ sudo systemctl disable NetworkManager-wait-online.service
[sudo] password for unarix: 
Removed symlink /etc/systemd/system/network-online.target.wants/NetworkManager-wait-online.service.
unarix@linuxlord ~ $ sudo systemctl disable pppd-dns.service
Synchronizing state of pppd-dns.service with SysV init with /lib/systemd/systemd-sysv-install...
Executing /lib/systemd/systemd-sysv-install disable pppd-dns
insserv: warning: current start runlevel(s) (empty) of script `pppd-dns' overrides LSB defaults (S).
insserv: warning: current stop runlevel(s) (S) of script `pppd-dns' overrides LSB defaults (empty).
unarix@linuxlord ~ $ sudo systemctl disable ModemManager.service
Removed symlink /etc/systemd/system/dbus-org.freedesktop.ModemManager1.service.
Removed symlink /etc/systemd/system/multi-user.target.wants/ModemManager.service.
unarix@linuxlord ~ $ sudo systemctl disable lvm2-monitor.service
Removed symlink /etc/systemd/system/sysinit.target.wants/lvm2-monitor.service.
unarix@linuxlord ~ $ 







sudo systemctl disable ModemManager.service
The service pppd-dns.service (used for dial-up modems) is probably unnecessary for most modern systems, so disable it in the same way:

sudo systemctl disable pppd-dns.service
The name of the service is the same as it appears in the output of systemd-analyze blame. Remember that the name is case sensitive. Use the full name that includes the .service part.

Which Services Should I Disable?
By default, systemd-analyze blame lists services from the top to bottom by order of the longest time, so focus on the topmost services since they are what slow down the boot time. In every Linux installation I had, the NetworkManager-wait-online.service was the biggest culprit to long boot times. It added 8 seconds to every boot for no reason whatsoever — and I did not need this service to run the system or use networking. Disabling this one service alone reduced the Linux boot time by 8 seconds. Wow!

sudo systemctl disable NetworkManager-wait-online.service
My system boots and networking functions perfectly without this service.

Other services I disabled included:

pppd-dns.service
lvm2-monitor.service
ModemManager.service
On a Linux Mint 18.1 installation, disabling these services reduced the userspace boot time to ~1.8 seconds. On another Linux Mint 18.1 system, the userspace boot time was reduced to 1.001s.

Services that consume less than 50ms can usually be ignored, but those requiring 100ms or more are worth investigating. Services will be disabled upon the next system boot.

Some services are required, and disabling them will cause parts of your system not to function properly. Many are “bonus” services that add little to the value of an installation. For example, VirtualBox (if installed) requires the vboxdrv.service, but the other services it installs

vboxweb.service
vboxballoonctrl.service
vboxautostart-service.service
are unnecessary for my purposes, so I disabled them. VirtualBox runs as good as it always does in the absence of these extra three services.

Enabling a Service
Service descriptions can be esoteric, so search for exact descriptions online before disabling one. If you disable a service that your system needs, you can always enable it again.

sudo systemctl enable <service-name.service>

Other times, a needed service will be loaded even if you disable it. On the next boot, the service might load if it is required by another part of the system. This can vary, so educate yourself about what the various services do so you can best determine whether to keep it or not.

Sometimes, you will have nothing to rely upon besides trial and error.
