basico: instalar el code y el dotnet (core)
    apt-get install dotnet-dev-1.0.0-rc4-004771
    https://code.visualstudio.com/

Creando un proyecto web (https://docs.microsoft.com/en-us/aspnet/core/client-side/yeoman):

1- instalar npm y nodejs
    en mint/ubuntu hay que instalar tambien sudo nodejs-legacy (crea una especie de link simbolico de una carpeta a otra que hace falta.. magic!)
2- instalar yeoman
    npm install -g yo bower (correr con sudo!)
3- Con yeoman instalar el generador de una emty web app de ASP.NET
    https://docs.microsoft.com/en-us/aspnet/core/client-side/yeoman
    npm install -g generator-aspnet
4- Genial; ahora hay que correr el generador de la empty app en la carpeta donde queremos crear el proyecto
    yo aspnet
5- Hacer lo que dice al final, es importante (restore, build y run)
6- Comprobar que el proyecto corre en el puerto indicado

Haciendo magia desde el Code! (http://jakeydocs.readthedocs.io/en/latest/tutorials/your-first-mac-aspnet.html)

1- como creamos un proyecto MVC, tenemos que leer esto, proque no tenemos ni puta idea de que hicimos:
    https://docs.microsoft.com/en-us/aspnet/core/tutorials/first-mvc-app/adding-controller
2- 
