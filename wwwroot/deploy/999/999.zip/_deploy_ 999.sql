set echo on
set define on
accept sdm prompt "Por favor ingrese el número de solicitud de SDM: "
-- Obtiene fecha
column dcol new_value mydate noprint
select '_'||to_char(sysdate,'YYYYMMDD_HH24MI') dcol from dual;
spool _deploy_sdm_&&sdm.&mydate
set define off
-- Aquí debe enumerar los scripts.sql que desea desplegar sobre la BD.
@".\1_script.sql"
@".\2_script.sql"
@".\3_script.sql"
spool off
